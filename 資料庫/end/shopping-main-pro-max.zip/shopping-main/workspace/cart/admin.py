from django.contrib import admin
from cart.models import Order

# Register your models here.
admin.site.register(Order)
